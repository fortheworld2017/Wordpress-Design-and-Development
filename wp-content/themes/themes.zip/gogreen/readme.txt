===================================
GOGREEN - Organic Food, Farm, Market Business WordPress Theme
===================================
website: http://wydethemes.com/gogreen


===================================
FREE CUSTOMER SUPPORT
===================================
https://themeforest.net/user/Wyde#contact
https://themeforest.net/item/gogreen-business-wordpress-theme/16966736/support

===================================
CREDITS
===================================

Images & Videos
-----------------------------------

All images and videos in the live preview are for demo purposes only and are not included with your purchase.

Images:

123RF
DeathtoStock
FoodiesFeed
Pexels
Picjumbo
Pixabay
Unsplash
https://www.flickr.com/photos/astragony
https://www.flickr.com/photos/danielviero

Videos:

CinemaExpert


Fonts
-----------------------------------

The font in sliders is not included with your purchase. However, you can download it free for personal use in below link:

Bromello

Font icons:

Farming
BigMug Line by Catalin Fertu
Simple Line Icons By Jamal Jama
Linecons by Designmodo


JavaScript & jQuery plugins
-----------------------------------

jQuery
Modernizr
Waypoints
Retina
waitForImages
scrollTo
debouncedresize
prettyPhoto
Isotope
sly
Owl Carousel
History


PHP Libraries & WordPress Plugins
-----------------------------------

Redux Framework
TGM-Plugin-Activation
CMB2


===================================
UPDATE LOG
===================================
Version 1.0.2 (latest update)
-Updated Visual Composer 5.0.1
-Updated Slider Revolution 5.3.0.2
-Updated Wyde Core plugin
-Updated GoGreen Metaboxes
-Updated Lightbox video fullscreen
-Updated Footer pages list in Theme Options
-Fixed Animations on mobile


Version 1.0.1 - 30-10-2016
-Added Google Maps Coordinates option
-Updated Mobile Menu
-Updated Animations on Content Elements
-Updated Theme full name and details
-Updated Demo Content plugin
-Updated Documentation
-Updated Password Form on password protected post
-Fixed Title Area on product page


Version 1.0.0 - 03-09-2016
-Initial Release