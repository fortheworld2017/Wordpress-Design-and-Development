<span class="meta-comment">
	<?php comments_popup_link( '<i class="w-comment-empty"></i>0', '<i class="w-comment"></i>1', '<i class="w-comment"></i>%'); ?>
</span>