<div class="loader-timer">
	<div></div>
</div>